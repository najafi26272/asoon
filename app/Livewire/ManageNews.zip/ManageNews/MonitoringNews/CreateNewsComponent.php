<?php

namespace App\Livewire\ManageNews\MonitoringNews;

use Livewire\Component;
use App\Models\{News,NewsStep};
use Illuminate\Support\Facades\Auth;

class CreateNewsComponent extends Component
{
    public $title,$link,$content,$summary,$agency,$topic,$reason,$goals;

    public function submit(){
        $this->validate([
            'title' => ['required'],
            'link' => ['required']
        ]);
        $data = News::create([
            'creator_id' => Auth::user()->id,
            'title' => trim($this->title),
            'link' => $this->link,
            'goals' => $this->goals,
            'topic' => $this->topic,
            'summary' => $this->summary,
        ]);
        $step = NewsStep::create([
            'news_id' => $data->id,
            'step_id' => 1,
            'creator_id' => Auth::user()->id,
        ]);
        $data->update(['status' => $step->id]);

        $this->reset();
        $this->dispatch('$_news_refresh');
        $this->dispatch('news_created');
        $this->dispatch('$_success_full_message');
    }

    public function render()
    {
        return view('livewire.manage-news.monitoring-news.create-news-component');
    }
}
